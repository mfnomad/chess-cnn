uint64_t blockers = // 64-Bit kodiertes Schachbrett, wobei nur die tiefsten 12 Bits gesetzt sind
uint64_t magic    = // vorgerechnete "magische" Zahl
                   
                   // die Multiplikation bewirkt ein "Durchmischen" der gesetzten Bits
int index         = (blockers * magic) >> (64 - 12); 
//der abschließender Shift liefert die 12 hoechsten Bits
// Index ist somit eine Zahl zwischen 0 und 4095